#import <Preferences/PSListController.h>

@interface DIPRootListController : PSListController
@end
