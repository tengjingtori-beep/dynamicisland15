# DynamicIsland15

iPhone 7 / iOS 15（Dopamine・palera1n 等の rootless 脱獄）向けの
Dynamic Island 再現 tweak です。Sileo でインストールできる `.deb` を
GitHub Actions で自動ビルドします。

## 本物との一致 / 違い（正直に）

一致させたところ:
- 待機時のピル寸法 126×37pt、純黒、上端から約 11pt、完全な角丸
  （iPhone 14 Pro の実機値が基準）
- 広がり方のスプリングアニメーション、展開時の最大幅 371pt
- 音楽再生時の「最小表示」（左にアートワーク、右に波形が分離する実機の挙動）
- イベント連動: 音楽（曲名・アーティスト・アートワーク・波形アニメーション）、
  通話（着信・発信・通話時間のカウント表示）、充電（⚡＋バッテリー %、約 4 秒で自動で戻る）
- v1.1 (FakeNotch 方式): ピル右端にカメラレンズを描画、上辺に密着する
  ノッチスタイルも選択可能。AirPods / ヘッドホン接続、フラッシュライトの
  オン/オフもバナー表示
- v1.2: ロック解除 (Touch ID) の瞬間に Face ID 風アニメーション
  （顔グリフが広がってチェックに変わる実機の動き）を表示。
  時計アプリのタイマーの残り時間をピル内にカウントダウン表示
  （Live Activities 風。MobileTimer 内部 API に依存する実験的実装で、
  環境により読めない場合は表示されません）
- タップで展開 / 縮小

どうしても違うところ:
- iPhone 7 にはカメラの切り欠き（穴）そのものがありません。
  これは画面の上に黒いピルを「重ねて表示」する再現で、ハードウェアの
  穴にはなりません。ベゼルや画面の明るさの質感も実機とは異なります。
- Face ID そのもの（顔認証）は iPhone 7 に部品が無いので動きません。
  v1.2 の Face ID は「ロック解除時のアニメーションの再現」です
  （実際の認証は Touch ID）。
- Live Activities の仕組み自体は iOS 16 以降のものなので、iOS 15 では
  連携ではなく tweak 内での再現になります。「本物の機能がすべて使える」
  状態はハードウェアと OS の都合で不可能です
  （対応は音楽・通話・着信発信・充電・AirPods 接続・ライト・
  ロック解除アニメーション・タイマー表示）。

「本物としか言えない完全一致」はハードウェア上不可能なので、
ソフトウェアで可能な限り寄せた、という位置づけです。

## 動作環境
- iPhone 7（A10 / arm64）、iOS 15.x
- rootless 脱獄（Dopamine / palera1n rootless）＋ Sileo
- 依存: mobilesubstrate（ElleKit で可）、preferenceloader

## ビルド（Mac 不要）
1. GitHub に公開リポジトリを作り、このプロジェクト（または
   DynamicIsland15.zip 1 個）を置く
2. Actions の「Build DEB」が自動で走る（手動実行も可）
3. Artifacts の `DynamicIsland15-deb` から `.deb` をダウンロード

失敗したら Artifacts の `build-log` を見てください。

## インストール
- ダウンロードした `.deb` を iPhone へ送り、Sileo で開く
  （共有メニューから Sileo、または Filza でタップ）→ インストール → リスプリング
- 設定アプリに「DynamicIsland15」が追加されます
  （有効/無効、上からの位置、大きさ。変更は即時反映）

## 構成
```
Makefile / control / DynamicIsland15.plist   Theos (rootless)
Tweak.x                                      本体 (SpringBoard フック)
dynamicisland15prefs/                        設定画面 (PreferenceLoader)
layout/Library/PreferenceLoader/...          設定の入口
.github/workflows/build-deb.yml              自動ビルド
```
