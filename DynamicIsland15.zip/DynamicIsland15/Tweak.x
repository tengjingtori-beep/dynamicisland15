// DynamicIsland15 — iPhone 7 / iOS 15 向け Dynamic Island 再現 tweak
//
// 実機 (iPhone 14 Pro 以降) の寸法・色・動きを可能な限り一致させている:
//  - 待機時ピル: 幅 126pt × 高さ 37pt、純黒 (#000)、完全な角丸、上端から約 11pt
//  - 展開時: 最大幅 371pt までスプリングアニメーション (damping 0.72 前後) で拡大
//  - 音楽再生時は「最小表示」(左にアートワーク、右に波形) に分割
//  - 優先順位: 通話 > 音楽 > 充電バナー > 待機
//
// iPhone 7 にはカメラの切り欠き自体が無いため、画面上に重ねる表示になる。
// ハードウェアの穴そのものは再現できない (README 参照)。

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <CallKit/CallKit.h>
#import <AVFoundation/AVFoundation.h>
#import <dlfcn.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <mach/mach.h>

// ---------- 設定 ----------
static BOOL prefEnabled = YES;
static CGFloat prefTopOffset = 11.0;   // 実機準拠
static CGFloat prefWidthScale = 1.0;   // 1.0 = 実機寸法
static BOOL prefShowLens = YES;        // FakeNotch 方式: カメラレンズを描く
static BOOL prefNotchStyle = NO;       // FakeNotch 方式: 上辺に密着させる
static BOOL prefFaceIDAnim = YES;      // ロック解除時に Face ID 風アニメーション
static BOOL prefTimerLive = YES;       // 時計アプリのタイマーを表示
static NSString * const kPrefsDomain = @"app.hane.dynamicisland15";
static NSString * const kPrefsChanged = @"app.hane.dynamicisland15/prefsChanged";

static void loadPrefs(void) {
    CFPreferencesAppSynchronize((__bridge CFStringRef)kPrefsDomain);
    id v;
    v = (__bridge id)CFPreferencesCopyAppValue(CFSTR("Enabled"), (__bridge CFStringRef)kPrefsDomain);
    if (v) prefEnabled = [v boolValue];
    v = (__bridge id)CFPreferencesCopyAppValue(CFSTR("TopOffset"), (__bridge CFStringRef)kPrefsDomain);
    if (v) prefTopOffset = [v floatValue];
    v = (__bridge id)CFPreferencesCopyAppValue(CFSTR("WidthScalePercent"), (__bridge CFStringRef)kPrefsDomain);
    if (v) prefWidthScale = [v floatValue] / 100.0;
    v = (__bridge id)CFPreferencesCopyAppValue(CFSTR("ShowLens"), (__bridge CFStringRef)kPrefsDomain);
    if (v) prefShowLens = [v boolValue];
    v = (__bridge id)CFPreferencesCopyAppValue(CFSTR("NotchStyle"), (__bridge CFStringRef)kPrefsDomain);
    if (v) prefNotchStyle = [v boolValue];
    v = (__bridge id)CFPreferencesCopyAppValue(CFSTR("FaceIDAnimation"), (__bridge CFStringRef)kPrefsDomain);
    if (v) prefFaceIDAnim = [v boolValue];
    v = (__bridge id)CFPreferencesCopyAppValue(CFSTR("TimerLiveActivity"), (__bridge CFStringRef)kPrefsDomain);
    if (v) prefTimerLive = [v boolValue];
}

// ---------- MediaRemote (プライベート) を動的に読む ----------
typedef void (*MRRegisterFn)(dispatch_queue_t);
typedef void (*MRGetInfoFn)(dispatch_queue_t, void (^)(CFDictionaryRef));
static MRRegisterFn MRRegister = NULL;
static MRGetInfoFn MRGetInfo = NULL;
static CFStringRef kKeyTitle, kKeyArtist, kKeyArtwork, kKeyIsPlaying, kKeyNotifName;

static CFStringRef MRKey(void *handle, const char *symbol, const char *fallback) {
    CFStringRef *p = (CFStringRef *)dlsym(handle, symbol);
    if (p && *p) return *p;
    return (__bridge CFStringRef)[NSString stringWithUTF8String:fallback];
}

static void loadMediaRemote(void) {
    void *h = dlopen("/System/Library/PrivateFrameworks/MediaRemote.framework/MediaRemote", RTLD_LAZY);
    if (!h) return;
    MRRegister = (MRRegisterFn)dlsym(h, "MRMediaRemoteRegisterForNowPlayingNotifications");
    MRGetInfo = (MRGetInfoFn)dlsym(h, "MRMediaRemoteGetNowPlayingInfo");
    kKeyTitle = MRKey(h, "kMRMediaRemoteNowPlayingInfoTitle", "kMRMediaRemoteNowPlayingInfoTitle");
    kKeyArtist = MRKey(h, "kMRMediaRemoteNowPlayingInfoArtist", "kMRMediaRemoteNowPlayingInfoArtist");
    kKeyArtwork = MRKey(h, "kMRMediaRemoteNowPlayingInfoArtworkData", "kMRMediaRemoteNowPlayingInfoArtworkData");
    kKeyIsPlaying = MRKey(h, "kMRMediaRemoteNowPlayingInfoIsPlaying", "kMRMediaRemoteNowPlayingInfoIsPlaying");
    kKeyNotifName = MRKey(h, "kMRMediaRemoteNowPlayingInfoDidChangeNotification",
                             "kMRMediaRemoteNowPlayingInfoDidChangeNotification");
}

// ---------- アイランド本体 ----------
typedef NS_ENUM(NSInteger, DIContent) {
    DIContentNone = 0,
    DIContentMusic,
    DIContentCharging,
    DIContentCall,
    DIContentInfo,  // AirPods 接続・ライト点灯などの汎用バナー
    DIContentFaceID, // ロック解除時の Face ID 風アニメーション
    DIContentTimer   // 時計アプリのタイマー (Live Activities 風)
};

@interface DIIslandView : UIView
@property (nonatomic, strong) UIView *pill;
@property (nonatomic, strong) UIImageView *artworkView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subtitleLabel;
@property (nonatomic, strong) UIView *waveformView;
@property (nonatomic, strong) NSMutableArray<UIView *> *waveBars;
@property (nonatomic, strong) UIImageView *boltView;
@property (nonatomic, strong) UILabel *percentLabel;
@property (nonatomic, strong) UILabel *callLabel;
@property (nonatomic, strong) UIView *miniArtwork;
@property (nonatomic, strong) UIView *miniWave;
@property (nonatomic, strong) UIView *lensView;
@property (nonatomic, strong) UIImageView *faceView;
@property (nonatomic, strong) UIImageView *checkView;
- (void)layoutForContent:(DIContent)content expanded:(BOOL)expanded screenWidth:(CGFloat)sw animated:(BOOL)animated;
@end

@implementation DIIslandView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.backgroundColor = UIColor.clearColor;

    _pill = [[UIView alloc] init];
    _pill.backgroundColor = UIColor.blackColor;
    _pill.layer.shadowColor = UIColor.blackColor.CGColor;
    _pill.layer.shadowOpacity = 0.35;
    _pill.layer.shadowRadius = 12;
    _pill.layer.shadowOffset = CGSizeMake(0, 4);
    _pill.clipsToBounds = NO;
    [self addSubview:_pill];

    UIView *clip = [[UIView alloc] init];
    clip.clipsToBounds = YES;
    clip.tag = 9001;
    [_pill addSubview:clip];

    _artworkView = [[UIImageView alloc] init];
    _artworkView.contentMode = UIViewContentModeScaleAspectFill;
    _artworkView.clipsToBounds = YES;
    _artworkView.layer.cornerRadius = 10;
    [clip addSubview:_artworkView];

    _titleLabel = [[UILabel alloc] init];
    _titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    _titleLabel.textColor = UIColor.whiteColor;
    _titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    [clip addSubview:_titleLabel];

    _subtitleLabel = [[UILabel alloc] init];
    _subtitleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightRegular];
    _subtitleLabel.textColor = [UIColor colorWithWhite:1 alpha:0.6];
    _subtitleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    [clip addSubview:_subtitleLabel];

    // 波形 (再生中バー)
    _waveformView = [[UIView alloc] init];
    _waveBars = [NSMutableArray array];
    for (int i = 0; i < 4; i++) {
        UIView *bar = [[UIView alloc] init];
        bar.backgroundColor = [UIColor colorWithRed:0.19 green:0.85 blue:0.38 alpha:1];
        bar.layer.cornerRadius = 1.5;
        [_waveformView addSubview:bar];
        [_waveBars addObject:bar];
    }
    [clip addSubview:_waveformView];

    _boltView = [[UIImageView alloc] initWithImage:
        [UIImage systemImageNamed:@"bolt.fill"]];
    _boltView.tintColor = [UIColor colorWithRed:0.19 green:0.85 blue:0.38 alpha:1];
    _boltView.contentMode = UIViewContentModeScaleAspectFit;
    [clip addSubview:_boltView];

    _percentLabel = [[UILabel alloc] init];
    _percentLabel.font = [UIFont systemFontOfSize:17 weight:UIFontWeightSemibold];
    _percentLabel.textColor = UIColor.whiteColor;
    [clip addSubview:_percentLabel];

    _callLabel = [[UILabel alloc] init];
    _callLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    _callLabel.textColor = [UIColor colorWithRed:0.19 green:0.85 blue:0.38 alpha:1];
    [clip addSubview:_callLabel];

    // FakeNotch 方式のカメラレンズ (実機はピル右端にレンズが見える)
    _lensView = [[UIView alloc] init];
    _lensView.clipsToBounds = YES;
    _lensView.backgroundColor = [UIColor colorWithRed:0.03 green:0.03 blue:0.06 alpha:1];
    CAGradientLayer *lensGrad = [CAGradientLayer layer];
    lensGrad.colors = @[(id)[UIColor colorWithRed:0.10 green:0.14 blue:0.28 alpha:1].CGColor,
                        (id)[UIColor colorWithRed:0.02 green:0.02 blue:0.05 alpha:1].CGColor,
                        (id)[UIColor colorWithRed:0.16 green:0.10 blue:0.24 alpha:1].CGColor];
    lensGrad.startPoint = CGPointMake(0.2, 0.15);
    lensGrad.endPoint = CGPointMake(0.85, 0.9);
    lensGrad.frame = CGRectMake(0, 0, 24, 24);
    [_lensView.layer addSublayer:lensGrad];
    UIView *spec = [[UIView alloc] initWithFrame:CGRectMake(6, 5, 5, 5)];
    spec.backgroundColor = [UIColor colorWithWhite:1 alpha:0.35];
    spec.layer.cornerRadius = 2.5;
    [_lensView addSubview:spec];
    [clip addSubview:_lensView];

    // Face ID 風アニメーション用 (顔グリフ → チェック)
    _faceView = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"faceid"]];
    _faceView.tintColor = UIColor.whiteColor;
    _faceView.contentMode = UIViewContentModeScaleAspectFit;
    _faceView.alpha = 0;
    [clip addSubview:_faceView];
    _checkView = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"checkmark.circle.fill"]];
    _checkView.tintColor = [UIColor colorWithRed:0.19 green:0.85 blue:0.38 alpha:1];
    _checkView.contentMode = UIViewContentModeScaleAspectFit;
    _checkView.alpha = 0;
    [clip addSubview:_checkView];

    // 最小表示 (音楽再生中): 左の丸と右の波形
    _miniArtwork = [[UIView alloc] init];
    _miniArtwork.backgroundColor = UIColor.blackColor;
    _miniArtwork.clipsToBounds = YES;
    [self addSubview:_miniArtwork];
    _miniWave = [[UIView alloc] init];
    _miniWave.backgroundColor = UIColor.blackColor;
    _miniWave.clipsToBounds = YES;
    [self addSubview:_miniWave];

    return self;
}

- (CGSize)sizeForContent:(DIContent)content expanded:(BOOL)expanded screenWidth:(CGFloat)sw {
    CGFloat w = prefWidthScale;
    if (content == DIContentNone) return CGSizeMake(126 * w, 37);
    if (!expanded) {
        if (content == DIContentMusic) return CGSizeMake(126 * w, 37); // ピルは据え置き、最小表示は左右に分離
        if (content == DIContentTimer) return CGSizeMake(196 * w, 37); // 残り時間をピル内に表示
        return CGSizeMake(200 * w, 37);
    }
    switch (content) {
        case DIContentMusic:   return CGSizeMake(MIN(371 * w, sw - 16), 84);
        case DIContentCharging: return CGSizeMake(MIN(320 * w, sw - 16), 64);
        case DIContentCall:    return CGSizeMake(MIN(371 * w, sw - 16), 76);
        case DIContentInfo:    return CGSizeMake(MIN(320 * w, sw - 16), 64);
        case DIContentFaceID:  return CGSizeMake(MIN(210 * w, sw - 16), 64);
        case DIContentTimer:   return CGSizeMake(MIN(320 * w, sw - 16), 64);
        default:               return CGSizeMake(126 * w, 37);
    }
}

- (void)layoutForContent:(DIContent)content expanded:(BOOL)expanded screenWidth:(CGFloat)sw animated:(BOOL)animated {
    CGSize size = [self sizeForContent:content expanded:expanded screenWidth:sw];
    CGFloat topY = prefNotchStyle ? 0 : prefTopOffset;
    if (prefNotchStyle && content == DIContentNone) {
        size = CGSizeMake(MIN(230 * prefWidthScale, sw - 80), 30); // ノッチらしい幅
    }
    CGRect pillFrame = CGRectMake((sw - size.width) / 2.0, topY, size.width, size.height);
    BOOL minimalMusic = (content == DIContentMusic && !expanded);

    void (^apply)(void) = ^{
        self.pill.frame = pillFrame;
        self.pill.layer.cornerRadius = size.height / 2.0;
        // ノッチ密着時は上の角を四角く、下だけ丸く (FakeNotch の見た目)
        CACornerMask mask = prefNotchStyle
            ? (kCALayerMinXMaxYCorner | kCALayerMaxXMaxYCorner)
            : (kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner |
               kCALayerMinXMaxYCorner | kCALayerMaxXMaxYCorner);
        self.pill.layer.maskedCorners = mask;
        UIView *clip = [self.pill viewWithTag:9001];
        clip.frame = self.pill.bounds;
        clip.layer.cornerRadius = size.height / 2.0;
        clip.layer.maskedCorners = mask;

        // レンズはピル右端の内側 (実機位置)。情報バナー等では隠す
        BOOL lensVisible = prefShowLens && content != DIContentInfo;
        self.lensView.alpha = lensVisible ? 1 : 0;
        CGFloat lensSize = MIN(24, size.height - 10);
        self.lensView.frame = CGRectMake(size.width - lensSize - 8,
                                         (size.height - lensSize) / 2.0, lensSize, lensSize);
        self.lensView.layer.cornerRadius = lensSize / 2.0;

        BOOL showExpanded = (content != DIContentNone && expanded);
        self.artworkView.alpha = (showExpanded && content == DIContentMusic) ? 1 : 0;
        self.titleLabel.alpha = (showExpanded || content == DIContentTimer) ? 1 : 0;
        self.faceView.alpha = 0;
        self.checkView.alpha = 0;
        if (content == DIContentFaceID && expanded) {
            self.faceView.frame = CGRectMake(16, (size.height - 40) / 2.0, 40, 40);
            self.checkView.frame = self.faceView.frame;
            self.faceView.alpha = 1; // チェックへの切替はマネージャ側で制御
        }
        if (content == DIContentTimer) {
            self.titleLabel.frame = CGRectMake(14, (size.height - 20) / 2.0, size.width - 52, 20);
            self.titleLabel.textAlignment = NSTextAlignmentLeft;
        }
        self.subtitleLabel.alpha = (showExpanded && (content == DIContentMusic || content == DIContentInfo)) ? 1 : 0;
        self.waveformView.alpha = (showExpanded && content == DIContentMusic) ? 1 : 0;
        self.boltView.alpha = (showExpanded && content == DIContentCharging) ? 1 : 0;
        self.percentLabel.alpha = (showExpanded && content == DIContentCharging) ? 1 : 0;
        self.callLabel.alpha = (showExpanded && content == DIContentCall) ? 1 : 0;

        if (showExpanded) {
            CGFloat pad = 14;
            if (content == DIContentMusic) {
                self.artworkView.frame = CGRectMake(pad, (size.height - 54) / 2.0, 54, 54);
                CGFloat tx = pad + 54 + 12;
                self.titleLabel.frame = CGRectMake(tx, size.height / 2.0 - 20, size.width - tx - 104, 20);
                self.subtitleLabel.frame = CGRectMake(tx, size.height / 2.0 + 2, size.width - tx - 104, 18);
                self.waveformView.frame = CGRectMake(size.width - 84, size.height / 2.0 - 10, 30, 20);
            } else if (content == DIContentInfo) {
                self.titleLabel.frame = CGRectMake(pad + 6, size.height / 2.0 - 20, size.width - 40, 20);
                self.subtitleLabel.frame = CGRectMake(pad + 6, size.height / 2.0 + 2, size.width - 40, 18);
            } else if (content == DIContentCharging) {
                self.titleLabel.frame = CGRectMake(pad + 6, size.height / 2.0 - 10, size.width - 140, 20);
                self.boltView.frame = CGRectMake(size.width - 92, size.height / 2.0 - 11, 16, 22);
                self.percentLabel.frame = CGRectMake(size.width - 72, size.height / 2.0 - 12, 62, 24);
            } else if (content == DIContentCall) {
                self.callLabel.frame = CGRectMake(pad + 6, size.height / 2.0 - 10, size.width - 40, 20);
                self.titleLabel.frame = CGRectMake(pad + 6, size.height / 2.0 + 10, size.width - 40, 18);
            }
        }

        // 最小表示: ピルの左右に小さな要素を分離配置 (実機の minimal view)
        CGFloat mini = 37;
        CGFloat gap = 10;
        CGFloat centerLeft = CGRectGetMinX(pillFrame) - gap - mini;
        CGFloat centerRight = CGRectGetMaxX(pillFrame) + gap;
        self.miniArtwork.frame = CGRectMake(centerLeft, topY, mini, mini);
        self.miniArtwork.layer.cornerRadius = mini / 2.0;
        self.miniWave.frame = CGRectMake(centerRight, topY, mini, mini);
        self.miniWave.layer.cornerRadius = mini / 2.0;
        self.miniArtwork.alpha = minimalMusic ? 1 : 0;
        self.miniWave.alpha = minimalMusic ? 1 : 0;
    };

    if (animated) {
        [UIView animateWithDuration:0.65 delay:0
             usingSpringWithDamping:0.72 initialSpringVelocity:0.4
                            options:UIViewAnimationOptionAllowUserInteraction | UIViewAnimationOptionBeginFromCurrentState
                         animations:apply completion:nil];
    } else {
        apply();
    }
}

- (void)animateWavePlaying:(BOOL)playing {
    for (NSUInteger i = 0; i < self.waveBars.count; i++) {
        UIView *bar = self.waveBars[i];
        [bar.layer removeAllAnimations];
        CGFloat h = playing ? (8 + ((i * 7 + arc4random_uniform(8)) % 12)) : 6;
        bar.frame = CGRectMake(i * 8, (20 - h) / 2.0, 3, h);
        if (playing) {
            CABasicAnimation *a = [CABasicAnimation animationWithKeyPath:@"transform.scale.y"];
            a.fromValue = @0.4; a.toValue = @1.0;
            a.duration = 0.28 + i * 0.07;
            a.autoreverses = YES; a.repeatCount = HUGE_VALF;
            [bar.layer addAnimation:a forKey:@"wave"];
        }
    }
}

@end

// ---------- ウィンドウ (タッチはピル部分だけ受ける) ----------
@interface DIIslandWindow : UIWindow
@property (nonatomic, weak) DIIslandView *island;
@end
@implementation DIIslandWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hit = [super hitTest:point withEvent:event];
    if (hit == self || hit == self.rootViewController.view) return nil;
    return hit;
}
@end

// ---------- マネージャ ----------
@interface DIDManager : NSObject <CXCallObserverDelegate>
@property (nonatomic, strong) DIIslandWindow *window;
@property (nonatomic, strong) DIIslandView *island;
@property (nonatomic) DIContent content;
@property (nonatomic) BOOL expanded;
@property (nonatomic, strong) CXCallObserver *callObserver;
@property (nonatomic, strong) NSTimer *chargingTimer;
@property (nonatomic, strong) NSDate *callStart;
@property (nonatomic, strong) NSTimer *callTimer;
@property (nonatomic) BOOL wasLocked;
@property (nonatomic) BOOL musicPresent;
@property (nonatomic, strong) NSTimer *timerPoll;
+ (instancetype)shared;
- (void)setup;
- (void)refreshLayoutAnimated:(BOOL)animated;
- (void)nowPlayingChanged;
- (void)showInfoTitle:(NSString *)title subtitle:(NSString *)subtitle;
- (void)lockStateChanged;
@end

@implementation DIDManager

+ (instancetype)shared {
    static DIDManager *s; static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [[DIDManager alloc] init]; });
    return s;
}

- (void)setup {
    if (!prefEnabled) return;
    UIWindowScene *scene = nil;
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
        if (s.activationState == UISceneActivationStateForegroundActive &&
            [s isKindOfClass:UIWindowScene.class]) { scene = (UIWindowScene *)s; break; }
    }
    CGRect bounds = scene ? scene.coordinateSpace.bounds : UIScreen.mainScreen.bounds;
    self.window = [[DIIslandWindow alloc] initWithFrame:bounds];
    if (scene) self.window.windowScene = scene;
    self.window.windowLevel = UIWindowLevelStatusBar + 100;
    self.window.backgroundColor = UIColor.clearColor;
    UIViewController *vc = [[UIViewController alloc] init];
    vc.view.backgroundColor = UIColor.clearColor;
    self.window.rootViewController = vc;
    self.island = [[DIIslandView alloc] initWithFrame:bounds];
    self.island.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [vc.view addSubview:self.island];
    self.window.island = self.island;
    [self.window makeKeyAndVisible];
    self.window.hidden = NO;

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTap)];
    [self.island addGestureRecognizer:tap];

    [self refreshLayoutAnimated:NO];
    [self startNowPlaying];
    [self startBattery];
    [self startCalls];
    [self startAudioRoute];
    [self startLockState];
    [self startTimerPoll];
}

// --- ロック解除 → Face ID 風アニメーション ---
typedef mach_port_t (*SBServerPortFn)(void);
typedef void (*SBSLockStatusFn)(mach_port_t, BOOL *, BOOL *);
static SBServerPortFn SBPortFn = NULL;
static SBSLockStatusFn SBSLockFn = NULL;

- (BOOL)deviceLocked {
    if (!SBSLockFn) {
        void *h = dlopen("/System/Library/PrivateFrameworks/SpringBoardServices.framework/SpringBoardServices", RTLD_LAZY);
        if (!h) return NO;
        SBPortFn = (SBServerPortFn)dlsym(h, "SBSSpringBoardServerPort");
        SBSLockFn = (SBSLockStatusFn)dlsym(h, "SBSGetScreenLockStatus");
        if (!SBSLockFn) return NO;
    }
    BOOL locked = NO, passcode = NO;
    SBSLockFn(SBPortFn ? SBPortFn() : 0, &passcode, &locked);
    return locked;
}

- (void)startLockState {
    self.wasLocked = [self deviceLocked];
    extern void DILockStateCallback(CFNotificationCenterRef, void *, CFStringRef, const void *, CFDictionaryRef);
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
        DILockStateCallback, CFSTR("com.apple.springboard.lockstate"), NULL,
        CFNotificationSuspensionBehaviorDeliverImmediately);
}

- (void)lockStateChanged {
    BOOL locked = [self deviceLocked];
    BOOL unlockedNow = (self.wasLocked && !locked);
    self.wasLocked = locked;
    if (unlockedNow && prefFaceIDAnim && self.content != DIContentCall) {
        [self playFaceIDAnimation];
    }
}

- (void)playFaceIDAnimation {
    DIContent prev = self.musicPresent ? DIContentMusic : DIContentNone;
    [self setContent:DIContentFaceID expanded:YES animated:YES];
    self.island.faceView.transform = CGAffineTransformMakeScale(0.5, 0.5);
    self.island.faceView.alpha = 1;
    self.island.checkView.alpha = 0;
    [UIView animateWithDuration:0.45 delay:0.05 usingSpringWithDamping:0.6
          initialSpringVelocity:0.5 options:0 animations:^{
        self.island.faceView.transform = CGAffineTransformIdentity;
    } completion:nil];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.75 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        if (self.content != DIContentFaceID) return;
        [UIView animateWithDuration:0.2 animations:^{
            self.island.faceView.alpha = 0;
            self.island.checkView.alpha = 1;
        }];
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        if (self.content != DIContentFaceID) return;
        [self setContent:prev expanded:NO animated:YES];
    });
}

// --- タイマー (MobileTimer 内部 API を防御的に読む。無い環境では無効) ---
- (void)startTimerPoll {
    if (!prefTimerLive) return;
    self.timerPoll = [NSTimer scheduledTimerWithTimeInterval:1.0 repeats:YES
        block:^(NSTimer *t) { [[DIDManager shared] pollTimer]; }];
}

- (NSTimeInterval)timerRemaining {
    static void *handle = NULL;
    if (!handle) handle = dlopen("/System/Library/PrivateFrameworks/MobileTimer.framework/MobileTimer", RTLD_LAZY);
    if (!handle) return -1;
    id manager = nil;
    for (NSString *clsName in @[@"MTTimerManager", @"MTATimerManager"]) {
        Class cls = objc_getClass(clsName.UTF8String);
        if (!cls) continue;
        for (NSString *selName in @[@"sharedManager", @"sharedInstance"]) {
            SEL sel = NSSelectorFromString(selName);
            if ([cls respondsToSelector:sel]) {
                manager = ((id (*)(id, SEL))objc_msgSend)(cls, sel);
                if (manager) break;
            }
        }
        if (manager) break;
    }
    if (!manager) return -1;
    id timers = nil;
    @try {
        for (NSString *key in @[@"timers", @"currentTimers", @"scheduledTimers", @"currentTimer", @"nextTimer"]) {
            id v = nil;
            @try { v = [manager valueForKey:key]; } @catch (NSException *e) { v = nil; }
            if (v) { timers = v; break; }
        }
    } @catch (NSException *e) { return -1; }
    NSArray *list = nil;
    if ([timers isKindOfClass:NSArray.class]) list = timers;
    else if (timers) list = @[timers];
    if (!list.count) return -1;
    NSTimeInterval best = -1;
    for (id timer in list) {
        NSTimeInterval remaining = -1;
        @try {
            id fire = [timer valueForKey:@"fireDate"];
            if ([fire isKindOfClass:NSDate.class]) remaining = [fire timeIntervalSinceNow];
        } @catch (NSException *e) {}
        if (remaining < 0) {
            @try {
                id r = [timer valueForKey:@"remainingTime"];
                if ([r isKindOfClass:NSNumber.class]) remaining = [r doubleValue];
            } @catch (NSException *e) {}
        }
        if (remaining > 0 && (best < 0 || remaining < best)) best = remaining;
    }
    return best;
}

- (void)pollTimer {
    if (self.content == DIContentCall || self.content == DIContentFaceID) return;
    NSTimeInterval remaining = [self timerRemaining];
    if (remaining > 0) {
        if (self.content == DIContentNone || self.content == DIContentTimer) {
            int s = (int)ceil(remaining);
            self.island.titleLabel.textColor = [UIColor colorWithRed:1.0 green:0.62 blue:0.04 alpha:1];
            NSString *text = [NSString stringWithFormat:@"タイマー %02d:%02d", s / 60, s % 60];
            if (s >= 3600) text = [NSString stringWithFormat:@"タイマー %d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60];
            if (![self.island.titleLabel.text isEqualToString:text] || self.content != DIContentTimer) {
                self.island.titleLabel.text = text;
                [self setContent:DIContentTimer expanded:NO animated:(self.content != DIContentTimer)];
            }
        }
    } else if (self.content == DIContentTimer) {
        self.island.titleLabel.textColor = UIColor.whiteColor;
        [self setContent:DIContentNone expanded:NO animated:YES];
    }
}

// --- 汎用バナー (AirPods 接続 / ライトなど) ---
- (void)showInfoTitle:(NSString *)title subtitle:(NSString *)subtitle {
    if (self.content == DIContentCall || self.content == DIContentMusic) return;
    self.island.titleLabel.text = title ?: @"";
    self.island.subtitleLabel.text = subtitle ?: @"";
    [self setContent:DIContentInfo expanded:YES animated:YES];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(collapseInfo) object:nil];
    [self performSelector:@selector(collapseInfo) withObject:nil afterDelay:3.5];
}

- (void)collapseInfo {
    if (self.content == DIContentInfo) [self setContent:DIContentNone expanded:NO animated:YES];
}

// --- AirPods / ヘッドホン接続 ---
- (void)startAudioRoute {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(routeChanged:)
        name:AVAudioSessionRouteChangeNotification object:nil];
}

- (void)routeChanged:(NSNotification *)note {
    NSNumber *reason = note.userInfo[AVAudioSessionRouteChangeReasonKey];
    if (reason.unsignedIntegerValue != AVAudioSessionRouteChangeReasonNewDeviceAvailable) return;
    AVAudioSessionPortDescription *port = [AVAudioSession sharedInstance].currentRoute.outputs.lastObject;
    if (!port) return;
    NSString *type = port.portType;
    if ([type containsString:@"Bluetooth"] || [type containsString:@"Headphones"] ||
        [type isEqualToString:AVAudioSessionPortHeadphones]) {
        [self showInfoTitle:port.portName subtitle:@"接続されました"];
    }
}

- (CGFloat)screenWidth {
    return UIScreen.mainScreen.bounds.size.width;
}

- (void)refreshLayoutAnimated:(BOOL)animated {
    BOOL visibleContent = self.content != DIContentNone;
    [self.island layoutForContent:self.content
                         expanded:self.expanded && visibleContent
                      screenWidth:[self screenWidth]
                         animated:animated];
}

- (void)setContent:(DIContent)content expanded:(BOOL)expanded animated:(BOOL)animated {
    _content = content;
    _expanded = expanded;
    [self refreshLayoutAnimated:animated];
}

- (void)onTap {
    if (self.content == DIContentNone) return;
    self.expanded = !self.expanded;
    [self refreshLayoutAnimated:YES];
    if (self.expanded && self.content == DIContentCharging) {
        [self performSelector:@selector(collapseCharging) withObject:nil afterDelay:4];
    }
}

- (void)collapseCharging {
    if (self.content == DIContentCharging) [self setContent:DIContentNone expanded:NO animated:YES];
}

// --- 音楽 ---
- (void)startNowPlaying {
    loadMediaRemote();
    if (!MRRegister || !kKeyNotifName) return;
    MRRegister(dispatch_get_main_queue());
    // NSDistributedNotificationCenter は iOS SDK に無いため、2秒ごとのポーリングで代替
    [NSTimer scheduledTimerWithTimeInterval:2.0 repeats:YES
        block:^(NSTimer *t) { [[DIDManager shared] nowPlayingChanged]; }];
    [self nowPlayingChanged];
}

- (void)nowPlayingChanged {
    if (!MRGetInfo) return;
    MRGetInfo(dispatch_get_main_queue(), ^(CFDictionaryRef info) {
        NSDictionary *d = (__bridge NSDictionary *)info;
        NSString *title = d[(__bridge NSString *)kKeyTitle];
        BOOL playing = [d[(__bridge NSString *)kKeyIsPlaying] boolValue];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (self.content == DIContentCall) return;
            if (title.length > 0) {
                self.musicPresent = YES;
                self.island.titleLabel.textColor = UIColor.whiteColor;
                self.island.titleLabel.text = title;
                self.island.subtitleLabel.text = d[(__bridge NSString *)kKeyArtist] ?: @"";
                NSData *art = d[(__bridge NSString *)kKeyArtwork];
                if (art) self.island.artworkView.image = [UIImage imageWithData:art];
                if (self.content != DIContentMusic) {
                    [self setContent:DIContentMusic expanded:YES animated:YES];
                    [self performSelector:@selector(minimizeMusic) withObject:nil afterDelay:5];
                }
                [self.island animateWavePlaying:playing];
            } else if (self.content == DIContentMusic) {
                self.musicPresent = NO;
                [self setContent:DIContentNone expanded:NO animated:YES];
            } else {
                self.musicPresent = NO;
            }
        });
    });
}

- (void)minimizeMusic {
    if (self.content == DIContentMusic && self.expanded) {
        self.expanded = NO;
        [self refreshLayoutAnimated:YES];
    }
}

// --- 充電 ---
- (void)startBattery {
    UIDevice *dev = UIDevice.currentDevice;
    dev.batteryMonitoringEnabled = YES;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(batteryChanged)
        name:UIDeviceBatteryStateDidChangeNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(batteryChanged)
        name:UIDeviceBatteryLevelDidChangeNotification object:nil];
}

- (void)batteryChanged {
    UIDevice *dev = UIDevice.currentDevice;
    BOOL charging = (dev.batteryState == UIDeviceBatteryStateCharging ||
                     dev.batteryState == UIDeviceBatteryStateFull);
    if (charging && self.content != DIContentCall && self.content != DIContentMusic) {
        self.island.titleLabel.text = @"充電中";
        self.island.percentLabel.text = [NSString stringWithFormat:@"%d%%", (int)round(dev.batteryLevel * 100)];
        [self setContent:DIContentCharging expanded:YES animated:YES];
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(collapseCharging) object:nil];
        [self performSelector:@selector(collapseCharging) withObject:nil afterDelay:4];
    } else if (!charging && self.content == DIContentCharging) {
        [self collapseCharging];
    }
}

// --- 通話 (CallKit: CXCallObserver) ---
- (void)startCalls {
    self.callObserver = [[CXCallObserver alloc] init];
    [self.callObserver setDelegate:self queue:dispatch_get_main_queue()];
}

- (void)callObserver:(CXCallObserver *)callObserver callChanged:(CXCall *)call {
    if (call.hasEnded) {
        [self.callTimer invalidate]; self.callTimer = nil;
        self.callStart = nil;
        if (self.content == DIContentCall) [self setContent:DIContentNone expanded:NO animated:YES];
    } else if (call.hasConnected) {
        if (!self.callStart) {
            self.callStart = [NSDate date];
            self.island.titleLabel.text = @"通話中";
            self.island.callLabel.text = @"00:00";
            [self setContent:DIContentCall expanded:YES animated:YES];
            __weak typeof(self) weakSelf = self;
            self.callTimer = [NSTimer scheduledTimerWithTimeInterval:1 repeats:YES block:^(NSTimer *t) {
                __strong typeof(weakSelf) self = weakSelf;
                if (!self || !self.callStart) return;
                NSTimeInterval s = [[NSDate date] timeIntervalSinceDate:self.callStart];
                self.island.callLabel.text = [NSString stringWithFormat:@"%02d:%02d", (int)s / 60, (int)s % 60];
            }];
        }
    } else if (call.isOutgoing) {
        self.island.titleLabel.text = @"発信中";
        self.island.callLabel.text = @"電話";
        [self setContent:DIContentCall expanded:YES animated:YES];
    } else {
        self.island.titleLabel.text = @"着信中";
        self.island.callLabel.text = @"電話";
        [self setContent:DIContentCall expanded:YES animated:YES];
    }
}

@end

// ---------- フラッシュライト (クラスが存在する場合だけ有効化) ----------
@interface SBFlashlightController : NSObject
- (void)turnFlashlightOn:(unsigned long long)level;
- (void)turnFlashlightOff;
@end

%group FlashlightHooks
%hook SBFlashlightController
- (void)turnFlashlightOn:(unsigned long long)level {
    %orig;
    [[DIDManager shared] showInfoTitle:@"フラッシュライト" subtitle:@"オン"];
}
- (void)turnFlashlightOff {
    %orig;
    [[DIDManager shared] showInfoTitle:@"フラッシュライト" subtitle:@"オフ"];
}
%end
%end

// ---------- 起動 ----------
@interface SpringBoard : UIApplication
@end

%hook SpringBoard
- (void)applicationDidFinishLaunching:(UIApplication *)application {
    %orig;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [[DIDManager shared] setup];
    });
}
%end

void DINowPlayingCallback(CFNotificationCenterRef center, void *observer,
                          CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[DIDManager shared] nowPlayingChanged];
    });
}

void DILockStateCallback(CFNotificationCenterRef center, void *observer,
                         CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[DIDManager shared] lockStateChanged];
    });
}

static void prefsChangedCallback(CFNotificationCenterRef center, void *observer,
                                 CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    loadPrefs();
    DIDManager *m = [DIDManager shared];
    m.window.hidden = !prefEnabled;
    [m refreshLayoutAnimated:YES];
}

%ctor {
    loadPrefs();
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
        prefsChangedCallback, (__bridge CFStringRef)kPrefsChanged, NULL,
        CFNotificationSuspensionBehaviorDeliverImmediately);
    %init;
    if (objc_getClass("SBFlashlightController")) {
        %init(FlashlightHooks);
    }
}
